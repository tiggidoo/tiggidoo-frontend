import React from 'react';

export default function SignedInLinks {
    return(
        <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto">
                <Nav.Link href="#home">Logout</Nav.Link>

            </Nav>
        </Navbar.Collapse>
    );
}