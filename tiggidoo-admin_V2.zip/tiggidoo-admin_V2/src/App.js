//import './App.css';
import { BrowserRouter, Switch } from "react-router-dom";
import AuthRoute from './components/auth/AuthRoute';


import SignIn from './components/auth/SignIn'
import Dashboard from './components/views/Dashboard';

function App() {
  return (

    <BrowserRouter>
      <div className="App">

          <Switch>
{/* 
            <Route exact path="/" component={SignIn} />
            <Route path="/dashboard" component={Dashboard} /> 
             */}

          {/* <Route exact path="/" component={SignIn} /> */}
          <AuthRoute exact path="/" type="guest" >
            <SignIn />
          </AuthRoute>
          <AuthRoute path="/dashboard" type="private">
            <Dashboard />
          </AuthRoute>
        </Switch>          
      </div>
    </BrowserRouter>

  );
}

export default App;
