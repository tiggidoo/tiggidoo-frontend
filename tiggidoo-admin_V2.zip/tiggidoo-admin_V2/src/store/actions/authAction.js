import axios from 'axios';

export const authAction = (email, password) => async dispatch => {
    try{
        
        dispatch({
            type: "LOGIN_PROCESSING"
        });    

        const f = new FormData();
        f.append('email', email);
        f.append('password', password);
        
        await axios.post('https://www.api-tiggidoo.com/api/login', f, {headers: {'Content-Type': 'multipart/form-data'}})
        .then(res => {
            dispatch({
                type: "LOGIN_SUCCESS",
                payload: res.data
            })
        }).then(otr => {
            console.log("Esta es una prueba");
            console.log(otr);
        }).catch((error) => {
            dispatch({
                type: "LOGIN_FAIL",
                //payload: credentials,
                error,
            })
        });
    }catch (error) {
        dispatch({
            type: "LOGIN_FAIL",
            //payload: credentials,
            error,
        })
    }
}

export const signOut = () => {
    return (dispatch, getState, { getFirebase }) => {
        const firebase = getFirebase();
        firebase.auth().signOut()
        .then(
            () => {
                dispatch({ type: 'SIGNOUT_SUCCESS' })
            }
        );
    }
}