const initState = {
    isAuthUser: false,
    user: '',
    access_token: '',
    authError: null
};

/* This is an error function */
const authReducer = (state = initState, action) => {
    switch (action.type) {
        case 'LOGIN_ERROR':
            console.log('LOGIN ERROR');
            return {
                ...state,
                authError: 'Login failed'
            };
        case 'LOGIN_SUCCESS':

            console.log('LOGIN SUCCESS');
            console.log(action.payload);

            return {
                ...state,
                isAuthUser: true,
                user: action.payload.user,
                access_token: action.payload.access_token,
                authError: null
            };

        case 'SIGNOUT_SUCCESS':
           console.log('LOGOUT SUCCESS');
           return state;
        default:
            return state;
    }
}

export default authReducer;